#include <stdio.h>
#include <stdlib.h>

void reverse(char *ptrx, char *reversed, int n); 

int main() {
    char *ptrx;
    char *reversed;
    int n;
    
    printf("Enter the size of the sentence: "); 
    scanf("%d", &n); 
    
    ptrx = (char*) malloc(n); 
    
    if(ptrx == NULL) {
    printf("Error! Memory not allocated.\n");
    return 1; 
    }

    printf("Enter a string: ");
    
    for(int i = 0; i < n; ++i) { 
        scanf("%c", ptrx + i); 
    }

    reversed = (char*) malloc((n + 1) );
    if(reversed == NULL) {
        printf("Error! Memory not allocated.\n");
        free(ptrx); 
        return 1; 
    } 
  
    reverse(ptrx, reversed, n); 

    printf("Reversed string: ");
    for (int i = 0; i < n; i++) {
     printf("%c", reversed[i]);
}
   

    free(reversed); 
    free(ptrx); 
    return 0; 
}

void reverse(char *ptrx, char *reversed, int n) {
    for (int i = 0; i < n; i++) {
        reversed[i] = ptrx[n - 1 - i]; 
    }
    reversed[n] = '\0'; 
}

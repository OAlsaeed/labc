#include <stdio.h>
#include <stdlib.h>

int main() {
    int *samples;  
    int count = 0;        
    int capacity = 1;     
    char choice;          
    int sample;           
    float sum = 0.0;      


    samples = malloc(capacity * sizeof(int));
    if (!samples) {
     printf("Memory allocation failed.\n");
     return 1; 
    }

    printf("Enter a sample: ");
    scanf("%d", &sample);
    samples[count++] = sample; 
    sum += sample;          

     while (1) {
     printf("Do you want to add more samples (y/n)? ");
     scanf(" %c", &choice); 
     if (choice == 'y' || choice == 'Y'){
      samples = realloc(samples, (capacity +1)* sizeof(int));
      printf("Enter a sample: ");
      scanf("%d", &sample);
      samples[count++] = sample; 
      sum += sample;       
        }   
         else {
            break; 
        }
    }
        float average = sum / count;
        printf("Adjusted samples after DC shift:\n");
        for (int i = 0; i < count; i++) {
        printf("%d ", samples[i] - (int)average); 
        }
        printf("\n");
        printf("No samples entered.\n");
    free(samples);
    return 0;
}



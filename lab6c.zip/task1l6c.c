
#include <stdio.h>
#include <stdlib.h>

void scaler(int *ptrx, int *ptry, int *ptrz, int a, int b, int n);

int main()
{
    int a,b, *ptrx, *ptry,*ptrz,n,i;
    
    
    printf("\nEnter the value of scalar a and b: ");
    scanf("%d %d", &a,&b);
    
    printf("Enter the size of each vector: ");
    scanf("%d", &n);
    
    ptrx = (int*) malloc (n * sizeof(int));
    ptry = (int*) malloc (n * sizeof(int));
    ptrz = (int*) malloc (n * sizeof(int));
    
    if(ptrx == NULL || ptry == NULL ||ptrz == NULL ) {
    printf("Error! memory not allocated.");
    return 1;
    
    
}

    printf("Enter x elements: ");
    for(i = 0; i < n; ++i) {
     scanf("%d", ptrx + i); 

}

  printf("Enter y elements: ");
    for(i = 0; i < n; ++i) {
     scanf("%d", ptry + i); 
  
}
scaler(ptrx, ptry, ptrz, a, b, n);
   for(i = 0; i < n; ++i) {
     printf("%d ", ptrz [i]); 
  
}
free(ptrx);
free(ptry);
free(ptrz);
    return 0;
}

void scaler( int *ptrx, int *ptry, int *ptrz, int  a, int b, int n){
    for (int i = 0; i < n; i++) {
     ptrz[i] = a * ptrx[i] + b * ptry[i];
    }
}


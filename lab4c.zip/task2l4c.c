#include <stdio.h>

int main()
{
    int N,i,j;
    
    

    printf("Enter the number of minutes:\n");
    scanf("%d", &N);


    for(i= 0; i < N; i++){
        
     for(j= 0; j <= 59; j++){
       printf("%02d : %02d \n ",i,j);
    }
    
    }

    return 0;
} 


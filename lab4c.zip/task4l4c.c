#include <stdio.h>

int main() {
    
    int N[10];
    float avr,max, min, sum =0;

    printf("Enter the population of city 1: ");
    scanf("%d", &N[0]);
    if (N[0] < 0) {
        printf("Enter a postive number \n");
        return 0;
    }

    max = min = sum = N[0];


 

    for (int i = 1; i < 10; i++) {

     printf("Enter the population of city %d:", i+1);
      scanf("%d", &N[i]);
     if (N[i] < 0) {
        printf("Enter a postive number of cities or more than one.\n");
        return 0;
    }
    
        sum += N[i];
        if (N[i] > max)
           max = N[i];


        if (N[i] < min)
            min = N[i];
    }



    for (int i = 9; i >= 0; i--) {
    printf("Population of city %d : %d \n", i+1, N[i]); 
    }
   
    avr = sum / 10;
    printf("\n%.2f Mean population:\n",avr );
    printf("%.2f Maximum population:\n",max );
    printf("%.2f Minimum population:\n\n",min );

    return 0;
}










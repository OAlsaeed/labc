
/* #include <stdio.h>

int main()
{
    int N,i,j;
    
    

    printf("Enter the number of rows:\n");
    scanf("%d", &N);


    for(i= 1; i <= N; i++){
        
     for(j = 1; j <= N - i; j++){
            printf(" ");
        }
     for(j= 1; j <= i; j++){
       printf("*");
    }
    printf("\n");
    }

    return 0;
} */

#include <stdio.h>

int main()
{
    int N, i = 1, j;

    printf("Enter the number of rows:\n");
    scanf("%d", &N);

    while (i <= N) {
       
        j = 1;
        while (j <= N - i) {
            printf(" ");
            j++;
        }
     
        j = 1;
        while (j <= i) {
            printf("*");
            j++;
        }
        printf("\n");
        i++;
    }

    return 0;
}



#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    
    srand(time(0));
    int image[10][10][3];  
    float grayscaleImage[10][10];
    
    printf("Original RGB values:\n");
    for (int row = 0; row < 10; row++) {
      for (int col = 0; col < 10; col++) {
         image[row][col][0] = rand() % 256;  
         image[row][col][1] = rand() % 256;  
         image[row][col][2] = rand() % 256;  

            
          printf("Pixel (%d, %d): (%d,%d,%d\n)", row, col, image[row][col][0], image[row][col][1], image[row][col][2]);
          
          grayscaleImage[row][col] = 0.299 * image[row][col][0] + 0.587 * image[row][col][1] + 0.114 * image[row][col][2];
        }
    }

    
    printf("\nGrayscale values:\n");
    for (int row = 0; row < 10; row++) {
        for (int col = 0; col < 10; col++) {
            printf("Pixel (%d, %d): Grayscale=%.2f\n", row, col, grayscaleImage[row][col]);
        }
    }

    return 0;
}


#include <stdio.h>
#include <time.h>
#include <stdlib.h>
int main()
{
    int j,i,y,x;
    
    srand(time(0));
    x = rand() % 10;
    y = rand() % 10;
    

    for(i= 0; i < 10; i++){
        
     for(j= 0; j < 10; j++){
    
   if (i ==x && j == y) {
     printf("Hurrah!, I have found the hidden treasure at %d,%d \n ",i,j);
     return 0;
    }}
    
    }

    return 0;
} 

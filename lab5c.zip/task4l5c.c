
#include <stdio.h>
int StringLength(char sentence[]);
int NumOfWords(char sentence[], int StrLengt);
int NumOfVowels(char sentence[], int StrLength);
void VowelFreq (char sentence[]);
int main() {
   char sentence[100];
   int Strl;
   int Nwords, Nvowels;
   
   printf("Enter a sentence max 100 characters: ");
   scanf("%100[^\n]", sentence); 
   
   Strl = StringLength(sentence);
   
   printf("Length of the sentence is: %d\n", Strl);
   
    Nwords = NumOfWords(sentence, Strl);
    printf("Number of words in the sentence is: %d\n", Nwords);
    
    Nvowels = NumOfVowels(sentence, Strl);
    printf("Number of vowels in the sentence is: %d\n", Nvowels);
   
   VowelFreq (sentence);
   
    return 0;
}

int StringLength(char sentence[]){
    int i=0;
    for (i; sentence[i] != '\0'; i++); 
    return i;
}

int NumOfWords(char sentence[], int StrLengt){
    int Nwords = 1;

    for (int i = 0; sentence[i] != '\0'; ++i) {
        if (sentence[i] == ' ') {
            Nwords++;
        }
    }

    return Nwords;
}
int NumOfVowels(char sentence[], int StrLengt){
    int count_a = 0, count_e = 0, count_i = 0, count_o = 0, count_u = 0;


    for (int i = 0; sentence[i] != '\0'; ++i) {
       if (sentence[i] == 'a' || sentence[i] == 'A') {
            count_a++;
        } else if (sentence[i] == 'e' || sentence[i] == 'E') {
            count_e++;
        } else if (sentence[i]== 'i' || sentence[i]== 'I') {
            count_i++;
        } else if (sentence[i]== 'o' || sentence[i] == 'O') {
            count_o++;
        } else if (sentence[i] == 'u' || sentence[i] == 'U') {
            count_u++;
        } 

    }

    return count_a + count_e + count_i + count_o + count_u;
}
void VowelFreq(char sentence[]){
    int count_a = 0, count_e = 0, count_i = 0, count_o = 0, count_u = 0;


    for (int i = 0; sentence[i] != '\0'; ++i) {
       if (sentence[i] == 'a' || sentence[i] == 'A') {
            count_a++;
        } else if (sentence[i] == 'e' || sentence[i] == 'E') {
            count_e++;
        } else if (sentence[i]== 'i' || sentence[i]== 'I') {
            count_i++;
        } else if (sentence[i]== 'o' || sentence[i] == 'O') {
            count_o++;
        } else if (sentence[i] == 'u' || sentence[i] == 'U') {
            count_u++;
        } 

    }

    printf("count_a= %d , count_e=%d , count_i=%d , count_o=%d , count_u=%d \n" ,count_a , count_e , count_i , count_o , count_u);
}

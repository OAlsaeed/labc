#include <stdio.h>
#define pi 3.1415192653

int addo(int a, int b);
float addf(float a, float b);
float circ_a(float r);
float rect_a(float H, float W);
unsigned int factorial(unsigned int n);

int main() {
    
    int a = 5, b = 3;
    float radius = 4.0, height = 5.0, width = 6.0;
    unsigned int num = 5;

    printf("Addition of %d and %d: %d\n", a, b, addo(a, b));
    printf("Addition of %.2f and %.2f: %.2f\n", 2.5f, 3.5f, addf(2.5, 3.5));
    printf("Area of a circle with radius %.2f: %.2f\n", radius, circ_a(radius));
    printf("Area of a rectangle with height %.2f and width %.2f: %.2f\n", height, width, rect_a(height, width));
    printf("Factorial of %u: %u\n", num, factorial(num));

    return 0;
}

int addo(int a, int b) {
    return a + b;
}

float addf(float a, float b) {
    return a + b;
}

float circ_a(float r) {
    return r * r * pi;  
}

float rect_a(float H, float W) {
    return H * W;  
}

unsigned int factorial(unsigned int n) {
    if (n == 0 || n == 1) return 1;  
    return n * factorial(n - 1);   
}


#include <stdio.h>

int main()
{
  short myage = 1;
  char *ptr;
  ptr = (char*) &myage;
 
 
  if (*ptr == 1)
   {
      printf("Little-endian\n");
   }
   else
   {
      printf("Big-endian\n");
   }

     if (sizeof(void*) == 4) {
        printf("System is 32-bit\n");
    } else 
        printf("System is 64-bit\n");
     return 0;     
}
   


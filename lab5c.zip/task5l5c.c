# include <stdio.h>
void MatrixVectorMultiply(int r, int c,int matrix[][c],int vector[],int result[]);
int main() {
    int r, c;

    printf("Enter the number of rows in the matrix: ");
    scanf("%d", &r);
    printf("Enter the number of columns in the matrix: ");
    scanf("%d", &c);

    int matrix[r][c];
    int vector[c];
    int result[r];

    printf("Enter the elements of the matrix:\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("Matrix[%d][%d]: ", i, j);
            scanf("%d", &matrix[i][j]); 
            
        }
        }
    for (int j = 0; j < c; j++) {
         printf("Vector[%d]: ", j);
         scanf("%d", &vector[j]);
    }
    for (int j = 0; j < c; j++) {
         result[j]=0;      
    }
    
    MatrixVectorMultiply(r, c, matrix, vector, result);
    
    
        return 0;
    }
    
    void MatrixVectorMultiply(int r, int c,int matrix[][c],int vector[],int result[]){
        for (int i = 0; i < r; i++) {
          for (int j = 0; j < c; j++) {
          result[i] += matrix[i][j] * vector[i]; 
          
        } printf("%d \n",result[i]);
    }}

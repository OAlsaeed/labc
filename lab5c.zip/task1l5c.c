#include <stdio.h>
# define n  4
int main()
{
    int inta [n];
    char chara [n];
    short shorta [n];
    double doublea [n];
    
    
     printf("Integer Array: \n");
    for (int i = 0; i < n; i++) {
      printf("%p\n", &inta[i]);
    }
  
    printf("\ncharacter Array: \n");
    for (int i = 0; i < n; i++) {
      printf("%p\n", &chara[i]);
    }
        printf("\n");
    printf("\nshort Array: \n");
    for (int i = 0; i < n; i++) {
      printf("%p\n", &shorta[i]);
    }
    
    printf("\nDouble Array: \n");
    for (int i = 0; i < n; i++) {
      printf("%p\n", &doublea[i]);
    }


    return 0;
}

#include <stdio.h>

int main() {
    int N;
    float avr, population, max, min, sum =0;
    
  
    printf("Enter the number of cities: \n ");
    scanf("%d", &N);

    
    if (N <= 1) {
        printf("Enter a postive number of cities or more than one.\n");
        return 0;
    }

    printf("Enter the population of city 1: ");
    scanf("%f", &population);
    

    max = min = sum = population;
  
    for (int i = 2; i <= N; i++) {
        
     printf("Enter the population of city %d:", i);
      scanf("%f", &population);
        
        sum += population;
        if (population > max)
            max = population;

        
        if (population < min)
            min = population;
        
        
    }

    avr = sum / N;

    printf("\n%.2f Mean population:\n",avr );
    printf("%.2f Maximum population:\n",max );
    printf("%.2f Minimum population:\n\n",min );

    return 0;
}


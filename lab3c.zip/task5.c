#include <stdio.h>

int main() {
    int N, ocount = 0;
    int count_a = 0, count_e = 0, count_i = 0, count_o = 0, count_u = 0; 
    char ch;

   
    printf("Enter the number of characters: ");
    scanf("%d", &N);

    
    for (int i = 1; i <= N; i++) {
        printf("Enter character %d: ", i);
        scanf(" %c", &ch); 

        
        if (ch == 'a' || ch == 'A') {
            count_a++;
        } else if (ch == 'e' || ch == 'E') {
            count_e++;
        } else if (ch == 'i' || ch == 'I') {
            count_i++;
        } else if (ch == 'o' || ch == 'O') {
            count_o++;
        } else if (ch == 'u' || ch == 'U') {
            count_u++;
        } else {
            ocount++; 
        }
    }

    
    printf("\nFrequency of vowels:\n");
    printf("a: %d\n", count_a);
    printf("e: %d\n", count_e);
    printf("i: %d\n", count_i);
    printf("o: %d\n", count_o);
    printf("u: %d\n", count_u);

    
    printf("\nFrequency of other characters: %d\n", ocount);

    return 0;
}

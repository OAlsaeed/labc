#include <stdio.h>

int main() {
    int x, y;  
    char move; 

    int min_x = 1, min_y = 1, max_x = 4, max_y = 4;

    
    printf("Enter initial position (x, y) in the range 1 to 4: ");
    scanf("%d %d", &x, &y);

 
    if (x < min_x || x > max_x || y < min_y || y > max_y) {
        printf("Invalid position\n");
        return 1;
    }

    
    while (1) {
        printf("Enter the direction U (Up), D (Down), L (Left), or R (Right): ");
        scanf(" %c", &move);

        
        if (move == 'U') {
            if (y > min_y) {
                y--;  
            } else {
                printf("The player has reached the boundary at (%d,%d)\n", x, y);
                break;
            }
        } else if (move == 'D') {
            if (y < max_y) {
                y++;  
            } else {
                printf("The player has reached the boundary at (%d,%d)\n", x, y);
                break;
            }
        } else if (move == 'L') {
            if (x > min_x) {
                x--;  
            } else {
                printf("The player has reached the boundary at (%d,%d)\n", x, y);
                break;
            }
        } else if (move == 'R') {
            if (x < max_x) {
                x++;  
            } else {
                printf("The player has reached the boundary at (%d,%d)\n", x, y);
                break;
            }
        } else {
            printf("Invalid direction!\n");
            continue;  
        }

        
        printf("Current position: (%d,%d)\n", x, y);
    }

    return 0;
}


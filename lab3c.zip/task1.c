
#include <stdio.h>
#include <stdlib.h>  

int main()
{
    int N;
    int i;
    float ff;

    printf("Enter a positive integer N:\n");
    scanf("%d", &N);
    
    i = N;
    
    // Print numbers from N to 0 in descending order
    printf("Numbers from %d to 0 in descending order:\n", N);
    for(; N >= 0; N--) 
        printf("%d ", N);
     
    printf("\nNumbers from 1 to %d following pattern B:\n", i);
    for(N = 1; N <= i; N++){ 
      if(N==4 || N==7 || N==14 || N==17) continue;
        printf("%d ", N);
    }
    // Prompt the user to enter an increment value
    printf("\nEnter an increment value less than 1:\n");
    scanf("%f", &ff);

    
    if (ff >= 1 || ff <=0) {
        printf("Error: Increment value must be less than 1 and greater tahn zero.\n");
        exit(1);  // Exit the program if increment is invalid
    }

    // Print floating-point numbers from 0 to i with the given increment
    printf("Floating-point numbers from 0 to %d incremented by %.2f:\n", i, ff);
    for(float f = 0; f <= i; f += ff) 
        printf("%.2f ", f);
    
    return 0;
}

